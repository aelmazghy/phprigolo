<?php  include 'config.php'; ?>
<?php  include 'header.php'; ?>

<script>
$(document).ready(function() {
	$('.menu-link').menuFullpage();
} );
</script>
<?php  include 'footer.php'; ?>